<template>
	<div>header</div>
</template>

<script>
import Demo from '../../demo/basic/Demo'
import Demo from '@/demo/basic/Demo'
// import Demo from '@/demo/basic/Demo'

export default {};
</script>

<style></style>
